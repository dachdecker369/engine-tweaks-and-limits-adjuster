#include "pch.h"
#include <cstdint>
#include <string_view>
#include <cassert>
#include "Game.h"
#include <fstream>
#include "Logging.h"

bool g_isEnhanced;
BYTE* splash;
BYTE* legal;
BYTE* landingPage;

// TODO (refactor): add null checks for patterns and tolerate missing patterns by skipping the patch

void initializeGame()
{
	ClearLog();

	g_isEnhanced = [] {
		char path[MAX_PATH];
		GetModuleFileNameA(GetModuleHandleA(nullptr), path, MAX_PATH);

		const char* filename = strrchr(path, '\\');
		filename = filename ? filename + 1 : path;

		return (_stricmp(filename, "GTA5_Enhanced.exe") == 0);
	}();

	DWORD oldProtect;

	// Splash and Legal screen patches were adapted from ChaosModV 
	// https://github.com/gta-chaos-mod/ChaosModV/blob/9301f701dcd29e558a7955f260a3fcb327e66a21/ChaosMod/Memory/Memory.cpp
	if (g_isEnhanced)
	{
		splash = MemScanner::FindPatternBmh("0F 85 A9 00 00 00 48 8D 54");
		legal = MemScanner::FindPatternBmh("00 E9 ? 05 00 00 E8 ? 07");

		splash -= 0x0D;
		legal -= 0x0F;

		VirtualProtect(splash, 6, PAGE_EXECUTE_READWRITE, &oldProtect);

		memcpy(splash, "\xE9\x86\x01\x00\x00\x90", 6);

		VirtualProtect(splash, 6, oldProtect, &oldProtect);

		VirtualProtect(legal, 6, PAGE_EXECUTE_READWRITE, &oldProtect);

		memcpy(legal, "\x90\x90\x90\x90\x90\x90", 6);

		VirtualProtect(legal, 6, oldProtect, &oldProtect);

	}
	else
	{
		splash = MemScanner::FindPatternBmh("48 8d 55 ? e8 ? ? ? ? 84 c0 74 ? 48 8b 05") + 9;
		legal = MemScanner::FindPatternBmh("83 ec ? 84 c9 74 ? 83 25 ? ? ? ? 00");

		VirtualProtect(splash, 3, PAGE_EXECUTE_READWRITE, &oldProtect);

		memcpy(splash, "\x90\x90\xEB", 3);

		VirtualProtect(splash, 3, oldProtect, &oldProtect);

		VirtualProtect(legal, 1, PAGE_EXECUTE_READWRITE, &oldProtect);

		memcpy(legal, "\xC3", 1);

		VirtualProtect(legal, 1, oldProtect, &oldProtect);

		legal += 9;

		BYTE* unkValAddr = (BYTE*)(*(int32_t*)legal + legal + 4 + 3);

		*unkValAddr = (BYTE)0x02;
	}


	// Thanks to "Unknown Modder" (alloc8or) for the landing page patch on Enhanced
	landingPage = MemScanner::FindPatternBmh(g_isEnhanced ? "E8 ? ? ? ? 8B 0D ? ? ? ? 83 C1 ? 84 C0" : "E8 ? ? ? ? 84 C0 8B 05 ? ? ? ? 74 ? 83 C0") + 1;
	// The legacy pattern is found even on very old builds, but the behavior is untested for them
	BYTE* patchedFuncAddr = (BYTE*)(*(int32_t*)landingPage + landingPage + 4);

	VirtualProtect(patchedFuncAddr, 3, PAGE_EXECUTE_READWRITE, &oldProtect);

	memcpy(patchedFuncAddr, "\x31\xC0\xC3", 3);

	VirtualProtect(patchedFuncAddr, 3, oldProtect, &oldProtect);

	std::string msg = "Patch successful!";
	Logging(msg);
}

void FatalErrorExit() {
	Logging("FATAL ERROR, EXITING...");

	MessageBoxA(
		nullptr,
		"FATAL ERROR.\nCheck the Log for details.",
		"StraightToStoryMode",
		MB_OK | MB_ICONERROR
	);

	exit(1);
}