#pragma once

#include <string>
#include <vector>

void initializeGame();
void FatalErrorExit();